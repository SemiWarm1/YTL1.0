const navItems = document.querySelectorAll(".nav-item");
const screens = document.querySelectorAll(".screen");
function setActiveTab(tabName) {
  navItems.forEach((item) => {
    item.classList.toggle("is-active", item.dataset.tab === tabName);
  });

  screens.forEach((screen) => {
    screen.classList.toggle("is-active", screen.dataset.screen === tabName);
  });
}

navItems.forEach((item) => {
  item.addEventListener("click", () => {
    setActiveTab(item.dataset.tab);
  });
});
